# Fitness Hub: face attendance + WhatsApp absence reminder backend

This is an integration package for the existing single-file `index.html` site. It does not replace the entire site HTML; use `index-integration.md` to patch the current file while preserving the design and payment/auth flows.

## Included
- `firestore.rules`: denies browser-side attendance writes and client access to biometric profiles.
- `functions/index.js`: callable prototype enrollment/check-in functions and scheduled WhatsApp template reminders.
- `index-integration.md`: exact integration patch for the current site.
- `firebase.json`, `functions/package.json`: deployment scaffolding.

## Important limitations before real members use it
1. Browser face descriptors are not a secure biometric proof. A determined user can spoof a browser request or enroll another person's face. This package is a prototype to wire the flow and secure the Firestore write path; it is **not production-grade identity verification**. For real gym access, use a trusted server-side biometric/liveness vendor or dedicated verified capture flow. Do not claim this has reliable anti-spoofing.
2. Biometric information is sensitive. Obtain explicit consent, explain retention/deletion, restrict access, encrypt where appropriate, and offer a manual alternative. Do not collect it from minors without the legally required parent/guardian consent and appropriate review.
3. WhatsApp sends require a Meta WhatsApp Business Platform account, a valid access token, phone-number ID, and an approved template. Provider charges/policies may apply.
4. Scheduled functions require Firebase's billing-enabled Blaze plan. See Firebase pricing before deploying.
5. The current website uses client-side owner payment approvals. These rules preserve that flow, but for a real paid membership service, move approval/activation into a verified owner-only Cloud Function and add stronger schema validation.

## Requirements
- Node.js 20
- Firebase CLI (`npm install -g firebase-tools`)
- Firebase project with Firestore and Authentication enabled
- A billing-enabled Firebase project for scheduled functions
- WhatsApp Business Platform credentials and approved template

## Setup
1. Back up the current `index.html` and current Firestore rules.
2. Copy `firestore.rules`, `firebase.json`, and `functions/` into the website project's root folder.
3. Replace `YOUR_FIREBASE_PROJECT_ID` with `fitness-hub-eb4e3` in `.firebaserc.example`, then rename it to `.firebaserc`.
4. Install/login:
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase use --add
   ```
   Select the existing `fitness-hub-eb4e3` project.
5. Set up functions:
   ```bash
   cd functions
   npm install
   cd ..
   ```
6. Configure WhatsApp secrets:
   ```bash
   firebase functions:secrets:set WA_TOKEN
   firebase functions:secrets:set WA_PHONE_NUMBER_ID
   ```
   Paste values when prompted. Never paste secrets into `index.html`, GitHub, or chat.
7. Configure optional parameters in `functions/.env.<project-id>` or Firebase parameter prompts:
   - `WA_GRAPH_VERSION` (default `v23.0`; set a currently supported version)
   - `WA_TEMPLATE_NAME` (default `missed_checkin_reminder`)
   - `WA_TEMPLATE_LANGUAGE` (default `en`)
8. Apply the integration steps in `index-integration.md`. Host the site over HTTPS and self-host pinned face-api.js model assets under `/models`.
9. Deploy:
   ```bash
   firebase deploy --only firestore:rules,functions
   ```
10. Test with a non-production test member first. Verify:
    - member cannot write directly to `attendance`;
    - inactive membership cannot check in;
    - repeat check-in doesn't create a second record;
    - opt-out members never receive reminders;
    - opted-in absent members get at most one attempt per day;
    - failures are visible in `absenceNotifications`;
    - WhatsApp template is accepted by Meta.
11. Set up the approved Meta template. `accepted` means the API accepted the send request, not that the member received/read it.

## Schedule
`sendAbsenceWhatsAppReminders` runs daily at 19:30 Asia/Kolkata. Change `schedule` in `functions/index.js` if the gym closes at a different time.

## Firestore data assumptions
- `users/{uid}`: `name`, `phone`, `whatsappAbsenceOptIn`
- `memberships/{uid}`: `expires` as Firestore Timestamp and `plan`
- `attendance/{uid_YYYY-MM-DD}`: server-created
- `faceProfiles/{uid}`: server-only descriptor (prototype only)
- `absenceNotifications/{uid_YYYY-MM-DD}`: server-only send log

## Rollback
If testing fails, restore your previous `firestore.rules` and site backup. Keep in mind restoring permissive rules can allow users to forge attendance; do not leave the old direct-write check-in code enabled alongside the new rules.

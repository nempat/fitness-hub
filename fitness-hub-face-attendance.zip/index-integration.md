# Integrate into your existing `index.html`

This guide is intentionally a patch, not a replacement for your full website. Keep your current CSS, public site, auth, payment, and membership UI.

## 0. Critical prototype warning

The supplied callable functions block direct client attendance writes and check membership server-side. However, the face descriptor is produced by the browser. A malicious user could fake the callable request or spoof enrollment. This is a prototype, not production-grade biometric authentication. Before real gym use, replace `enrollFacePrototype` and `verifyFaceAndCheckInPrototype` with a trusted biometric/liveness provider that verifies camera capture server-side. Provide a staff/manual alternative and get explicit consent.

## 1. Add the consent setting to your member profile

In the `regOnly` section, after the phone input, add:

```html
<label style="display:flex;gap:10px;align-items:flex-start;font-size:12px;color:var(--muted);margin:10px 0">
  <input id="waOptIn" type="checkbox" style="width:auto;margin:3px 0 0">
  I agree to receive WhatsApp reminders if I miss a gym day.
</label>
```

In your registration handler, read the checkbox and include `whatsappAbsenceOptIn` in the user document:
```js
const whatsappAbsenceOptIn = $('waOptIn')?.checked === true;
// Include this field in the setDoc user profile object:
{ name, phone, email: c.user.email, createdAt: serverTimestamp(), whatsappAbsenceOptIn }
```

For existing users, add an opt-in control in the member portal and save only their own preference:
```js
await setDoc(doc(db, 'users', auth.currentUser.uid), {
  whatsappAbsenceOptIn: $('waOptInMember').checked
}, { merge: true });
```
Add a checkbox with `id="waOptInMember"` in the member portal. Do not assume consent by default.

## 2. Add Face API script and enrollment/check-in UI

Before your `<script type="module">`, add the face-api.js browser library. Pin and self-host reviewed files for production rather than depending on a moving CDN:
```html
<script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
```

Inside `memberView`, replace the existing `CHECK IN TODAY` button with:
```html
<button class="btn btn-primary" id="faceEnrollBtn" style="margin-top:16px;width:100%">ENROL FACE</button>
<button class="btn btn-primary" id="checkBtn" style="margin-top:10px;width:100%">VERIFY FACE & CHECK IN</button>
<p class="muted" id="faceNote" style="margin-top:8px">Camera access is used for face matching. You can ask staff for manual verification.</p>
<video id="faceVideo" autoplay muted playsinline class="hidden" style="width:100%;max-width:360px;border:1px solid var(--border);margin-top:12px"></video>
```

Download the face-api.js model files (`tiny_face_detector`, `face_landmark_68`, `face_recognition`) from a reviewed, pinned source and host them under `/models`. Do not use a third-party model URL blindly in production.

## 3. Add callable imports

In the existing Firebase imports, add:
```js
import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js";
```

After `const app = initializeApp(firebaseConfig);`, add:
```js
const functions = getFunctions(app, "asia-south1");
const enrollFaceCall = httpsCallable(functions, "enrollFacePrototype");
const checkInFaceCall = httpsCallable(functions, "verifyFaceAndCheckInPrototype");
```

## 4. Add camera + face descriptor helpers

Add this inside the existing module after `const $ = ...`:

```js
let faceStream = null;
async function getFaceDescriptor() {
  if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera access requires HTTPS (or localhost).");
  if (!window.faceapi) throw new Error("Face library did not load. Reload and try again.");
  const video = $("faceVideo");
  $("faceNote").textContent = "Loading face models…";
  await Promise.all([
    faceapi.nets.tinyFaceDetector.loadFromUri("/models"),
    faceapi.nets.faceLandmark68Net.loadFromUri("/models"),
    faceapi.nets.faceRecognitionNet.loadFromUri("/models")
  ]);
  faceStream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: "user" }, audio: false
  });
  video.srcObject = faceStream;
  video.classList.remove("hidden");
  await new Promise(resolve => {
    if (video.readyState >= 2) return resolve();
    video.onloadedmetadata = () => resolve();
  });
  await video.play();
  // Short delay lets the camera exposure settle.
  await new Promise(resolve => setTimeout(resolve, 700));
  const result = await faceapi.detectSingleFace(
    video, new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.6 })
  ).withFaceLandmarks().withFaceDescriptor();
  if (!result) throw new Error("No clear face detected. Face the camera in good lighting.");
  const descriptor = Array.from(result.descriptor);
  faceStream.getTracks().forEach(t => t.stop());
  faceStream = null;
  video.srcObject = null;
  video.classList.add("hidden");
  return descriptor;
}
```

The helper above detects a face and calculates a descriptor. It does **not** provide liveness detection.

## 5. Replace the current check-in handler

Delete the existing handler:
```js
$('checkBtn').onclick = guard(async () => {
  const uid = auth.currentUser.uid, day = istDay();
  await setDoc(doc(db, 'attendance', `${uid}_${day}`), { uid, day, ts: serverTimestamp() });
  toast('Checked in!'); loadMember();
});
```

Replace it with:
```js
$('faceEnrollBtn').onclick = guard(async () => {
  if (!auth.currentUser) throw new Error("Please log in first.");
  const ok = confirm("Face enrollment stores a biometric template for attendance. Do you consent? You may ask staff for manual verification instead.");
  if (!ok) return;
  const descriptor = await getFaceDescriptor();
  await enrollFaceCall({ descriptor, consent: true });
  toast("Face enrolled. Remember: this prototype does not prove liveness.");
  loadMember();
});

$('checkBtn').onclick = guard(async () => {
  if (!auth.currentUser) throw new Error("Please log in first.");
  const descriptor = await getFaceDescriptor();
  await checkInFaceCall({ descriptor });
  toast("Face match accepted and attendance recorded.");
  loadMember();
});
```

## 6. Remove direct attendance writes

Do not leave any other browser code that calls `setDoc` or `addDoc` on the `attendance` collection. The new Firestore rules deny client writes and only the Cloud Functions Admin SDK can create records.

## 7. Profile rule note

The `users` rules allow the `faceConsent` fields to be written by the backend (Admin SDK bypasses rules), but the client `hasOnly` list must include fields your registration writes. This package includes `whatsappAbsenceOptIn`; if you add further user profile fields, update the allowlist carefully. Do not permit clients to write `faceProfiles`.

## 8. WhatsApp template

Create and get approval for a WhatsApp template with name `missed_checkin_reminder`, language `en`, and exactly two body variables, e.g.:

`Hi {{1}}, we missed you at {{2}} today. If you visited, please contact the gym team so we can check your attendance. See you soon!`

WhatsApp generally requires an approved template to initiate messages outside the customer-service window. Do not expect a free-form text message to work for scheduled reminders.

## 9. Owner dashboard

Your existing `Missed Check-ins` list is a manual click-to-WhatsApp list. Keep it as a fallback, but change its text to say automatic reminders run at 7:30 PM for members who opted in. A production UI should read `absenceNotifications` to show `accepted`/`failed`; `accepted` means the API accepted the request, not necessarily delivered it.

## 10. Deploy

See `README.md` for Firebase CLI commands and secret configuration.
